import React from 'react';
import Join from './join/Join';
import QuestionList from './questions/QuestionList';

import { Footer, Navbar, JoinUs } from "../../components";

import "./faq.css";

const FAQ = () => {
  

  return (
    <div className='faq_wrapper'>
      <Navbar />
      <QuestionList />
      <div className="homeContainer">
        <JoinUs />
        <Join />
        <Footer />
      </div>
    </div>
  )
}

export default FAQ;
