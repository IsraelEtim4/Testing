import React, { useState } from 'react';
import { 
  RxPlus, 
  RxBorderSolid 
} from "react-icons/rx";
import "./questionlist.css";

const Explanation = () => (
  <>
    <p className="explanation">
      For card debit transactions, a 1% transaction fee is applicable based on the transaction amount. However, there is a minimum charge of $1 and a maximum fee of $5.
    </p>
    <p className="explanation">
      Additionally, there is a $1 monthly maintenance fee per card. This fee will only be deducted after your first debit transaction in a given month.
    </p>
  </>
)

const QuestionList = () => {
  const [toggleExplain, setToggleExplain] = useState(false);

  return (
    <div className='questionList_wrapper'>
      <div className="about_top"></div>
      <div className="question">
        <button className="question1">
          <h3>What are the fees associated with transmission?</h3>
          <div className="bar">
            {toggleExplain
              ? <RxBorderSolid size={27} onClick={() => setToggleExplain(false)} />
              : <RxPlus size={27} onClick={() => setToggleExplain(true)} />
            }
          </div>
        </button>
        {toggleExplain && (
          <Explanation />
        )}
        <hr />
      </div>
    </div>
  )
}

export default QuestionList;
