import React from 'react';
import { 
  AiFillApple, 
  AiFillAndroid, 
  AiOutlineGlobal 
} from "react-icons/ai";

import moodsync from "../../../assets/moodsync3.png";
import "./join.css";

const Join = () => {
  return (
    <div className="land">
      <div className="ready">
        <div className="">
          <h3>Ready to join the <br/> Geng? Sign up today!</h3>
        </div>
        <div className="">
          <p>Available on</p>
        </div>
        <div className="app_button">
          <button className="apple_app">
            <div className="icon"><AiFillApple/></div>
            App store
          </button>
          <button className="play_app">
            <div className="icon"><AiFillAndroid/></div>
            Play store</button>
          <button className="web_app">
            <div className="icon"><AiOutlineGlobal /></div>
            Web App</button>
        </div>        
      </div>
      <div className="sample">
        <img src={moodsync} alt="" />
      </div>
    </div>
  )
}

export default Join;
