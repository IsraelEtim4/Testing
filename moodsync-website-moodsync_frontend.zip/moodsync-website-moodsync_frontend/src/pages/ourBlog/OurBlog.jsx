import React from 'react';
import { Footer, Navbar, JoinUs, Questions, } from "../../components";
import SpotLight from './spotlight/SpotLight';

import "./ourBlog.css";

const OurBlog = () => {
  return (
    <div className='OurBlog-wrapper'>
      <Navbar />
      <SpotLight />
      <div className="homeContainer">
        <JoinUs />
        <Questions />
        <Footer />
      </div>
    </div>
  )
}

export default OurBlog;
