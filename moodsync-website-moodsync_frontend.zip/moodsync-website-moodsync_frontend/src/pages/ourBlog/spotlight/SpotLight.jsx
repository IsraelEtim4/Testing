import React from 'react';
import "./spotlight.css";

const SpotLight = () => {
  return (
    <div className='spotlight-wrapper'>
      <div className="about_top"></div>
      <div className="spotlight_content">
        <div className="moddsync-spotlight_heading">
          <p className="topline">Answered Questions?</p>
          <h3 className="text_heading">Spotlight Stories</h3>
        </div>
        <div className="moodsync-spotlight">
          <div className="moodsync-spotlight-grid">
            <div className="moodsync-spotlight_background">
              <div className="moodsync-spotlight_background-content">
                <p>The Power of Music</p>
                <h3>How Moodsync is Transforming Your Mood</h3>
              </div>
            </div>
            <div className="spotlight_explain">
              <p>Music.Mood.Innovation</p>
              <h3>The Power of Music: How Moodsync is Trsnsforming your Mood</h3>
              <div className="names">
                <p>28th January, 2024</p>
                <p>Inyang Psalm</p>
              </div>
            </div>
          </div>
          <div className="moodsync-spotlight-grid">
            <div className="moodsync-spotlight_background">
              <div className="moodsync-spotlight_background-content">
                <p>The Power of Music</p>
                <h3>How Moodsync is Transforming Your Mood</h3>
              </div>
            </div>
            <div className="spotlight_explain">
              <p>Music.Mood.Innovation</p>
              <h3>The Power of Music: How Moodsync is Trsnsforming your Mood</h3>
              <div className="names">
                <p>28th January, 2024</p>
                <p>Inyang Psalm</p>
              </div>
            </div>
          </div>
          <div className="moodsync-spotlight-grid">
            <div className="moodsync-spotlight_background">
              <div className="moodsync-spotlight_background-content">
                <p>The Power of Music</p>
                <h3>How Moodsync is Transforming Your Mood</h3>
              </div>
            </div>
            <div className="spotlight_explain">
              <p>Music.Mood.Innovation</p>
              <h3>The Power of Music: How Moodsync is Trsnsforming your Mood</h3>
              <div className="names">
                <p>28th January, 2024</p>
                <p>Inyang Psalm</p>
              </div>
            </div>
          </div>
          <div className="moodsync-spotlight-grid">
            <div className="moodsync-spotlight_background">
              <div className="moodsync-spotlight_background-content">
                <p>The Power of Music</p>
                <h3>How Moodsync is Transforming Your Mood</h3>
              </div>
            </div>
            <div className="spotlight_explain">
              <p>Music.Mood.Innovation</p>
              <h3>The Power of Music: How Moodsync is Trsnsforming your Mood</h3>
              <div className="names">
                <p>28th January, 2024</p>
                <p>Inyang Psalm</p>
              </div>
            </div>
          </div>
          <div className="moodsync-spotlight-grid">
            <div className="moodsync-spotlight_background">
              <div className="moodsync-spotlight_background-content">
                <p>The Power of Music</p>
                <h3>How Moodsync is Transforming Your Mood</h3>
              </div>
            </div>
            <div className="spotlight_explain">
              <p>Music.Mood.Innovation</p>
              <h3>The Power of Music: How Moodsync is Trsnsforming your Mood</h3>
              <div className="names">
                <p>28th January, 2024</p>
                <p>Inyang Psalm</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SpotLight;
