export { default as Footer } from "./footer/Footer";
export { default as Header } from "./header/Header";
export { default as Navbar } from "./navbar/Navbar";
export { default as JoinUs } from "./joinUs/JoinUs";
export { default as OurProduct } from "./ourProduct/OurProduct";
export { default as Questions } from "./questions/Questions";